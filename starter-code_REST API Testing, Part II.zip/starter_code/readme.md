# Stores REST Api

This is built with Flask, Flask-RESTful, Flask-JWT, and Flask-SQLAlchemy.

Deployed on Heroku.
